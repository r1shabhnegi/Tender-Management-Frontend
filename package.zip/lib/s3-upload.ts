import axios from "axios";

interface UploadUrlResponse {
  success: boolean;
  url: string;
}

/**
 * Get a signed URL for uploading a file to S3
 */
export async function getUploadUrl(
  fileName: string,
  contentType: string
): Promise<string> {
  try {
    const response = await axios.post<UploadUrlResponse>("/api/s3/upload-url", {
      fileName,
      contentType,
    });
    return response.data.url;
  } catch (error) {
    console.error("Error getting upload URL:", error);
    throw error;
  }
}

/**
 * Upload a file directly to S3 using a signed URL
 */
export async function uploadFileToS3(url: string, file: File): Promise<void> {
  try {
    await axios.put(url, file, {
      headers: {
        "Content-Type": file.type,
      },
    });
  } catch (error) {
    console.error("Error uploading file to S3:", error);
    throw error;
  }
}

/**
 * Upload multiple files to S3 and return their file paths
 */
export async function uploadMultipleFilesToS3(
  files: File[]
): Promise<string[]> {
  try {
    // Generate unique filenames and get signed URLs for each file
    const uploadPromises = files.map(async (file) => {
      const uniqueFileName = generateUniqueFileName(file.name);
      const uploadUrl = await getUploadUrl(uniqueFileName, file.type);

      // Upload the file to S3
      await uploadFileToS3(uploadUrl, file);

      // Return the unique filename for database reference
      return uniqueFileName;
    });

    // Wait for all uploads to complete
    return await Promise.all(uploadPromises);
  } catch (error) {
    console.error("Error uploading multiple files:", error);
    throw error;
  }
}

/**
 * Helper function to generate a unique file name with timestamp
 */
export function generateUniqueFileName(originalName: string): string {
  const timestamp = Date.now();
  const extension = originalName.split(".").pop();
  const baseName = originalName.split(".").slice(0, -1).join(".");
  return `${baseName}-${timestamp}.${extension}`;
}
