// Mock data for development

export interface User {
  id: string;
  email: string;
  name: string;
}

export interface VenderProfile {
  id: string;
  full_name: string;
  status: "pending" | "rejected" | "approved";
  contact_number: string;
  pan_card_number: string;
  pan_card_doc_url: string;
  created_at: string;
  user_id: string;
}

export interface Business {
  id: string;
  business_name: string;
  business_classification: string;
  registration_number: string;
  registration_doc_url: string;
  established_year: string;
  address_line1: string;
  address_line2: string;
  locality: string;
  city: string;
  pin_code: string;
  country: string;
  created_at: string;
  user_id: string;
}

export interface Tender {
  id: string;
  title: string;
  description: string;
  organization: string;
}

export interface Bid {
  id: string;
  vender_id: string;
  tender_id: string;
  dd_number: string;
  dd_date: string;
  bank_number: string;
  bank_branch: string;
  technical_score?: number;
  financial_score?: number;
  status: "pending" | "rejected" | "approved";
  created_at: string;
  business_name: string;
  business_classification: string;
  total_score?: number;
}

// Generate mock data
export const mockVenders: VenderProfile[] = [
  {
    id: "vender_1",
    full_name: "John Doe",
    status: "approved",
    contact_number: "+91 9876543210",
    pan_card_number: "ABCDE1234F",
    pan_card_doc_url: "https://example.com/pan_card_1.pdf",
    created_at: "2023-01-15T10:30:00Z",
    user_id: "user_1",
  },
  {
    id: "vender_2",
    full_name: "Jane Smith",
    status: "pending",
    contact_number: "+91 9876543211",
    pan_card_number: "FGHIJ5678K",
    pan_card_doc_url: "https://example.com/pan_card_2.pdf",
    created_at: "2023-02-20T14:45:00Z",
    user_id: "user_2",
  },
  {
    id: "vender_3",
    full_name: "Robert Johnson",
    status: "rejected",
    contact_number: "+91 9876543212",
    pan_card_number: "LMNOP9012Q",
    pan_card_doc_url: "https://example.com/pan_card_3.pdf",
    created_at: "2023-03-10T09:15:00Z",
    user_id: "user_3",
  },
];

export const mockBusinesses: Business[] = [
  {
    id: "business_1",
    business_name: "Tech Solutions Ltd",
    business_classification: "IT Services",
    registration_number: "TECH12345",
    registration_doc_url: "https://example.com/reg_doc_1.pdf",
    established_year: "2010",
    address_line1: "123 Business Park",
    address_line2: "Sector 5",
    locality: "Salt Lake",
    city: "Kolkata",
    pin_code: "700091",
    country: "India",
    created_at: "2023-01-15T11:00:00Z",
    user_id: "user_1",
  },
  {
    id: "business_2",
    business_name: "Global Traders Inc",
    business_classification: "Import/Export",
    registration_number: "GLOB67890",
    registration_doc_url: "https://example.com/reg_doc_2.pdf",
    established_year: "2015",
    address_line1: "456 Trade Center",
    address_line2: "MG Road",
    locality: "Koramangala",
    city: "Bangalore",
    pin_code: "560034",
    country: "India",
    created_at: "2023-02-20T15:00:00Z",
    user_id: "user_2",
  },
  {
    id: "business_3",
    business_name: "Construct Pro Builders",
    business_classification: "Construction",
    registration_number: "CONS54321",
    registration_doc_url: "https://example.com/reg_doc_3.pdf",
    established_year: "2008",
    address_line1: "789 Builder Complex",
    address_line2: "Anna Salai",
    locality: "T Nagar",
    city: "Chennai",
    pin_code: "600017",
    country: "India",
    created_at: "2023-03-10T09:30:00Z",
    user_id: "user_3",
  },
];

export const mockTenders: Tender[] = [
  {
    id: "tender_1",
    title: "IT Infrastructure Upgrade",
    description: "Upgrade of IT infrastructure for government offices",
    organization: "Ministry of Technology",
  },
  {
    id: "tender_2",
    title: "Road Construction Project",
    description: "Construction of 50km highway connecting major cities",
    organization: "Highway Authority",
  },
  {
    id: "tender_3",
    title: "Healthcare Equipment Supply",
    description: "Supply of medical equipment to government hospitals",
    organization: "Ministry of Health",
  },
];

export const mockBids: Bid[] = [
  {
    id: "bid_1",
    vender_id: "user_1",
    tender_id: "tender_1",
    dd_number: "DD123456",
    dd_date: "2023-04-15",
    bank_number: "BANK123456",
    bank_branch: "Main Branch, Delhi",
    technical_doc_url: "https://example.com/tech_doc_1.pdf",
    financial_doc_url: "https://example.com/fin_doc_1.pdf",
    technical_score: 4,
    financial_score: 5,
    optional_info: "Additional certificates included",
    status: "approved",
    created_at: "2023-04-15T10:00:00Z",
  },
  {
    id: "bid_2",
    vender_id: "user_2",
    tender_id: "tender_1",
    dd_number: "DD789012",
    dd_date: "2023-04-16",
    bank_number: "BANK789012",
    bank_branch: "Central Branch, Mumbai",
    technical_doc_url: "https://example.com/tech_doc_2.pdf",
    financial_doc_url: "https://example.com/fin_doc_2.pdf",
    technical_score: 3,
    financial_score: 2,
    optional_info: null,
    status: "pending",
    created_at: "2023-04-16T14:30:00Z",
  },
  {
    id: "bid_3",
    vender_id: "user_3",
    tender_id: "tender_2",
    dd_number: "DD345678",
    dd_date: "2023-04-17",
    bank_number: "BANK345678",
    bank_branch: "City Branch, Kolkata",
    technical_doc_url: "https://example.com/tech_doc_3.pdf",
    financial_doc_url: "https://example.com/fin_doc_3.pdf",
    technical_score: 2,
    financial_score: 3,
    optional_info: "Previous experience documents attached",
    status: "rejected",
    created_at: "2023-04-17T09:45:00Z",
  },
  {
    id: "bid_4",
    vender_id: "user_1",
    tender_id: "tender_3",
    dd_number: "DD901234",
    dd_date: "2023-04-18",
    bank_number: "BANK901234",
    bank_branch: "Sector Branch, Hyderabad",
    technical_doc_url: "https://example.com/tech_doc_4.pdf",
    financial_doc_url: "https://example.com/fin_doc_4.pdf",
    technical_score: 1,
    financial_score: 4,
    optional_info: "ISO certificates included",
    status: "pending",
    created_at: "2023-04-18T11:15:00Z",
  },
  {
    id: "bid_5",
    vender_id: "user_2",
    tender_id: "tender_2",
    dd_number: "DD567890",
    dd_date: "2023-04-19",
    bank_number: "BANK567890",
    bank_branch: "Main Branch, Chennai",
    technical_doc_url: "https://example.com/tech_doc_5.pdf",
    financial_doc_url: "https://example.com/fin_doc_5.pdf",
    technical_score: 5,
    financial_score: 1,
    optional_info: null,
    status: "approved",
    created_at: "2023-04-19T16:00:00Z",
  },
];

// Helper function to get vendor profile by user id
export const getVenderByUserId = (
  userId: string
): VenderProfile | undefined => {
  return mockVenders.find((vender) => vender.user_id === userId);
};

// Helper function to get business by user id
export const getBusinessByUserId = (userId: string): Business | undefined => {
  return mockBusinesses.find((business) => business.user_id === userId);
};

// Helper function to get tender by id
export const getTenderById = (tenderId: string): Tender | undefined => {
  return mockTenders.find((tender) => tender.id === tenderId);
};
