"use client";
import React from "react";
import Protected from "../Components/Protected";
import { redirect } from "next/navigation";

const Profile = () => {
  return (
    <Protected>
      <div></div>
      <div>Profile</div>
      <div onClick={() => redirect("/")}>home</div>
    </Protected>
  );
};

export default Profile;
