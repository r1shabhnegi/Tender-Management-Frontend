import { useState, FormEvent, ChangeEvent } from "react";
import { uploadMultipleFilesToS3 } from "../lib/s3-upload";

interface FormData {
  title: string;
  description: string;
  fileUrls: string[];
  // Add more form fields as needed
}

export default function MultiFileUploadForm() {
  const [formData, setFormData] = useState<FormData>({
    title: "",
    description: "",
    fileUrls: [],
  });
  const [files, setFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleInputChange = (
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFiles = Array.from(e.target.files);

      // Validate all files are PDFs
      const invalidFiles = selectedFiles.filter(
        (file) => file.type !== "application/pdf"
      );
      if (invalidFiles.length > 0) {
        setError("All files must be PDFs");
        return;
      }

      // Check combined file size (limit to 50MB total)
      const totalSize = selectedFiles.reduce(
        (total, file) => total + file.size,
        0
      );
      if (totalSize > 50 * 1024 * 1024) {
        setError("Total file size exceeds 50MB limit");
        return;
      }

      setFiles(selectedFiles);
      setError(null);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(false);

    if (files.length === 0) {
      setError("Please select at least one file to upload");
      return;
    }

    try {
      setIsUploading(true);
      setUploadProgress(0);

      // Upload multiple files to S3
      const uploadedFileUrls = await uploadMultipleFilesToS3(files);

      // Update form data with file URLs
      const updatedFormData = {
        ...formData,
        fileUrls: uploadedFileUrls,
      };

      // Now submit the form data with the file URLs to your API
      console.log("Submitting data:", updatedFormData);

      // Example API call (implement based on your backend):
      // await axios.post('/api/your-endpoint', updatedFormData);

      setSuccess(true);
      setUploadProgress(100);

      // Reset form
      setFormData({
        title: "",
        description: "",
        fileUrls: [],
      });
      setFiles([]);
    } catch (err) {
      console.error("Error submitting form:", err);
      setError("Failed to submit form. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className='w-full max-w-md mx-auto p-6 bg-white rounded-lg shadow-md'>
      <h2 className='text-xl font-semibold mb-4'>Upload Multiple Documents</h2>

      {error && (
        <div className='mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded'>
          {error}
        </div>
      )}

      {success && (
        <div className='mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded'>
          Form submitted successfully!
        </div>
      )}

      <form
        onSubmit={handleSubmit}
        className='space-y-4'>
        <div>
          <label
            htmlFor='title'
            className='block text-sm font-medium text-gray-700 mb-1'>
            Title
          </label>
          <input
            id='title'
            name='title'
            type='text'
            required
            value={formData.title}
            onChange={handleInputChange}
            className='w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500'
          />
        </div>

        <div>
          <label
            htmlFor='description'
            className='block text-sm font-medium text-gray-700 mb-1'>
            Description
          </label>
          <textarea
            id='description'
            name='description'
            rows={3}
            value={formData.description}
            onChange={handleInputChange}
            className='w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500'
          />
        </div>

        <div>
          <label
            htmlFor='files'
            className='block text-sm font-medium text-gray-700 mb-1'>
            PDF Documents (Multiple)
          </label>
          <input
            id='files'
            name='files'
            type='file'
            accept='application/pdf'
            multiple
            onChange={handleFileChange}
            className='w-full'
          />
          {files.length > 0 && (
            <div className='mt-2'>
              <p className='text-sm text-gray-600 font-medium'>
                Selected files ({files.length}):
              </p>
              <ul className='mt-1 text-sm text-gray-500 list-disc pl-5'>
                {files.map((file, index) => (
                  <li key={index}>
                    {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                  </li>
                ))}
              </ul>
              <p className='mt-1 text-sm text-gray-600'>
                Total:{" "}
                {(
                  files.reduce((total, file) => total + file.size, 0) /
                  1024 /
                  1024
                ).toFixed(2)}{" "}
                MB
              </p>
            </div>
          )}
        </div>

        {isUploading && (
          <div className='w-full bg-gray-200 rounded-full h-2.5'>
            <div
              className='bg-blue-600 h-2.5 rounded-full'
              style={{ width: `${uploadProgress}%` }}></div>
          </div>
        )}

        <button
          type='submit'
          disabled={isUploading}
          className={`w-full py-2 px-4 rounded-md text-white font-medium ${
            isUploading ? "bg-blue-400" : "bg-blue-600 hover:bg-blue-700"
          }`}>
          {isUploading ? "Uploading..." : "Submit"}
        </button>
      </form>
    </div>
  );
}
