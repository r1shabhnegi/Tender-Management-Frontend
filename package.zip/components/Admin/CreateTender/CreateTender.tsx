"use client";
import React, { useEffect, useState, useCallback } from "react";
import { useForm, FormProvider } from "react-hook-form";
import ItemInfo from "./Forms/ItemInfo";
import TenderSupportDocument from "./Forms/TenderSupportDocument";
import VenderDocRequirement from "./Forms/VenderDocRequirement";
import {
  IItemInfo,
  IKeyDate,
  ITenderFeeDetails,
  ITenderPreQualification,
  ITenderSupportDocument,
  IVenderDocRequirement,
} from "@/app/Types";
import KeyDates from "./Forms/KeyDates";
import TenderFeeDetails from "./Forms/TenderFeeDetails";
import TenderPreQualifications from "./Forms/TenderPreQualifications";
import CreateTenderPreview from "./CreateTenderPreview";
import { useCreateTenderMutation } from "@/Redux/tender/tenderApi";
import { toast } from "sonner";
import { useGetCategoriesNamesQuery } from "@/Redux/category/categoryApi";
import AdminPagesWrapper from "../AdminPagesWrapper";

const CreateTender = () => {
  const [status, setStatus] = useState("");
  const [active, setActive] = useState<number>(0);

  const [createTender, { isLoading, isSuccess, isError, error }] =
    useCreateTenderMutation();

  const { data: categoriesData } = useGetCategoriesNamesQuery({});

  const methods = useForm({
    defaultValues: {
      // Item Info

      itemInfo: {
        company: "Teri",
        department: "",
        tenderNumber: "",
        tenderType: "",
        tenderScope: "",
        category: "",
        title: "",
        description: "",
        technicalPreBidQualification: "",
        technicalWeightage: "",
        commercialWeightage: "",
      },
      // Key Dates
      keyDates: {
        prePublishDate: "",
        publishDate: "",
        tenderSaleCloseDate: "",
        clarificationStartDate: "",
        clarificationEndDate: "",
        revisionPublishmentDate: "",
        bidSubmissionEndDate: "",
        bidOpenDate: "",
      },
      // Tender Fee Details

      tenderFeeDetails: {
        documentFee: "",
        feePayableAt: "",
        EMD: "",
        edmPayableAt: "",
        tenderLocation: "",
        tenderValue: "",
      },

      // Tender Support Documents
      tenderSupportDocuments: [
        {
          documentName: "",
          documentPurpose: "",
          document: "",
        },
      ],

      // Bidder Documents
      venderDocRequirement: [
        {
          name: "",
          type: "",
          purpose: "",
        },
      ],

      // Tender Pre-Qualifications
      tenderPreQualifications: [
        {
          title: "",
          description: "",
          score: "",
        },
      ],
    },
    mode: "onChange", // Enable automatic validation as fields change
  });

  // Define preview data state
  // const [isPreviewData, setIsPreviewData] = useState<{
  //   isItemInfo: IItemInfo;
  //   isKeyDates: IKeyDate;
  //   isTenderFeeDetails: ITenderFeeDetails;
  //   isTenderSupportDocuments: ITenderSupportDocument[];
  //   isVenderDocRequirement: IVenderDocRequirement[];
  //   isTenderPreQualification: ITenderPreQualification[];
  // }>({
  //   isVenderDocRequirement: [],
  //   isItemInfo: {} as IItemInfo,
  //   isKeyDates: {} as IKeyDate,
  //   isTenderFeeDetails: {} as ITenderFeeDetails,
  //   isTenderPreQualification: [],
  //   isTenderSupportDocuments: [],
  // });

  // Format data when navigating to preview
  // const formatData = useCallback(() => {
  //   const values = methods.getValues();

  //   const previewData = {
  //     isItemInfo: {
  //       company: values.company,
  //       department: values.department,
  //       tenderNumber: values.tenderNumber.toString(),
  //       tenderType: values.tenderType,
  //       tenderScope: values.tenderScope.toString(),
  //       category: values.category,
  //       title: values.title,
  //       description: values.description,
  //       technicalPreBidQualification: values.technicalPreBidQualification,
  //       technicalWeightage: values.technicalWeightage.toString(),
  //       commercialWeightage: values.commercialWeightage.toString(),
  //     },
  //     isKeyDates: {
  //       prePublishDate: values.prePublishDate,
  //       publishDate: values.publishDate,
  //       tenderSaleCloseDate: values.tenderSaleCloseDate,
  //       clarificationStartDate: values.clarificationStartDate,
  //       clarificationEndDate: values.clarificationEndDate,
  //       revisionPublishmentDate: values.revisionPublishmentDate,
  //       bidSubmissionEndDate: values.bidSubmissionEndDate,
  //       bidOpenDate: values.bidOpenDate,
  //     },
  //     isTenderFeeDetails: {
  //       documentFee: values.documentFee,
  //       feePayableAt: values.feePayableAt,
  //       EMD: values.EMD,
  //       edmPayableAt: values.edmPayableAt,
  //       tenderLocation: values.tenderLocation,
  //       tenderValue: values.tenderValue,
  //     },
  //     isTenderSupportDocuments: values.tenderSupportDocuments,
  //     isVenderDocRequirement: values.venderDocRequirement,
  //     isTenderPreQualification: values.tenderPreQualifications.map(
  //       (tenderPreQualification) => ({
  //         title: tenderPreQualification.title,
  //         description: tenderPreQualification.description,
  //         score: tenderPreQualification.score.toString(),
  //       })
  //     ),
  //   };

  //   setIsPreviewData(previewData);
  // }, [methods]);

  const isPreviewData = methods?.watch();
  console.log(isPreviewData);

  // Improved validation functions
  // const deepValidate = useCallback((value: any): boolean => {
  //   if (value === null || value === undefined) return false;

  //   if (value instanceof File) return true;

  //   if (Array.isArray(value)) {
  //     if (value.length === 0) return false;
  //     return value.every((elem) => deepValidate(elem));
  //   }

  //   if (typeof value === "object") {
  //     const keys = Object.keys(value);
  //     if (keys.length === 0) return false;
  //     return keys.every((key) => deepValidate(value[key]));
  //   }

  //   if (typeof value === "number") return true;
  //   if (typeof value === "string") return value.trim() !== "";

  //   return true;
  // }, []);

  // const validateDateFields = useCallback((dateObj: any): boolean => {
  //   return Object.values(dateObj).every(
  //     (dateStr: any) => dateStr === "" || !isNaN(Date.parse(dateStr))
  //   );
  // }, []);

  // const validateTenderData = useCallback(
  //   (data: {
  //     isItemInfo: any;
  //     isTenderSupportDocuments: any;
  //     isVenderDocRequirement: any;
  //     isKeyDates: any;
  //     isTenderFeeDetails: any;
  //     isTenderPreQualification: any;
  //   }): boolean => {
  //     return (
  //       deepValidate(data.isItemInfo) &&
  //       deepValidate(data.isTenderSupportDocuments) &&
  //       deepValidate(data.isVenderDocRequirement) &&
  //       deepValidate(data.isTenderFeeDetails) &&
  //       deepValidate(data.isTenderPreQualification) &&
  //       validateDateFields(data.isKeyDates)
  //     );
  //   },
  //   [deepValidate, validateDateFields]
  // );

  // Track API response status
  useEffect(() => {
    if (isSuccess) {
      toast.success("Tender created successfully");
      // Optionally reset form or navigate away
      methods.reset();
      setActive(0);
    } else if (isError) {
      console.log(error);
      toast.error("Technical error, Please try again later");
    }
  }, [isSuccess, isError, error, methods]);

  const onSubmit = async (data: any) => {
    // formatData();
    // const isVal = validateTenderData(isPreviewData);
    // if (!isVal) {
    //   toast.error("Please fill all required fields before publishing");
    //   return;
    // }
    // const formData = new FormData();
    // console.log("isPreviewData", isPreviewData);
    // // Append JSON data
    // formData.append("itemInfo", JSON.stringify(isPreviewData.isItemInfo));
    // formData.append(
    //   "venderDocRequirement",
    //   JSON.stringify(isPreviewData.isVenderDocRequirement)
    // );
    // formData.append("keyDates", JSON.stringify(isPreviewData.isKeyDates));
    // formData.append(
    //   "tenderFeeDetails",
    //   JSON.stringify(isPreviewData.isTenderFeeDetails)
    // );
    // formData.append(
    //   "tenderPreQualification",
    //   JSON.stringify(isPreviewData.isTenderPreQualification)
    // );
    // if (status === "live" || status === "draft") {
    //   formData.append("status", status);
    // } else {
    //   toast.error("Please select status");
    //   return;
    // }
    // // Append files
    // isPreviewData.isTenderSupportDocuments.forEach((doc, index) => {
    //   formData.append(
    //     `tenderSupportDocuments[${index}][documentName]`,
    //     doc.documentName
    //   );
    //   formData.append(
    //     `tenderSupportDocuments[${index}][documentPurpose]`,
    //     doc.documentPurpose
    //   );
    //   if (doc.document && doc.document[0] instanceof File) {
    //     formData.append(`tenderSupportDocuments`, doc.document[0]);
    //   }
    // });
    // try {
    //   await createTender(formData);
    // } catch (e) {
    //   console.error("Error creating tender:", e);
    //   toast.error("Failed to create tender due to technical error");
    // }
  };

  // useEffect(() => {
  //   formatData();
  // }, [active, formatData]);

  const createTenderNavData = [
    "Enter primary information",
    "Attach required files",
    "Specify required submissions.",
    "Specify important bid deadlines.",
    "Enter fee details.",
    "Enter eligibility details.",
    "Preview data before publishing.",
  ];

  const renderStep = () => {
    switch (active) {
      case 0:
        return (
          <ItemInfo
            setActive={setActive}
            categoriesData={categoriesData}
          />
        );
      case 1:
        return <TenderSupportDocument setActive={setActive} />;
      case 2:
        return <VenderDocRequirement setActive={setActive} />;
      case 3:
        return <KeyDates setActive={setActive} />;
      case 4:
        return <TenderFeeDetails setActive={setActive} />;
      case 5:
        return <TenderPreQualifications setActive={setActive} />;
      case 6:
        return (
          <CreateTenderPreview
            isLoading={isLoading}
            setActive={setActive}
            status={status}
            setStatus={setStatus}
            isPreviewData={isPreviewData}
          />
        );
      default:
        return null;
    }
  };

  return (
    <AdminPagesWrapper>
      <div className='mx-16 flex my-10 gap-2 flex-col items-center justify-center relative'>
        <h1 className='text-3xl text-gray-900 font-semibold'>Create Tender</h1>
        <p className='text-gray-700'>
          Fill in the required information to create a new tender
        </p>
      </div>

      <div className='flex justify-center gap-8 h-full'>
        <div
          className='max-w-[22%] w-full p-3 border border-blue-50 bg-card-color rounded-xl text-gray-900 overflow-auto flex flex-col gap-2.5 sticky top-36'
          style={{ height: "calc(100vh - 15rem)" }}>
          {createTenderNavData?.map((data, i) => (
            <div
              key={data}
              className={`hover:bg-card-color-darker1 cursor-pointer rounded-lg pl-4 pr-2.5 py-2.5 ${
                active === i ? "bg-card-color-darker1" : ""
              }`}
              onClick={() => setActive(i)}>
              <p className='font-medium text-sm flex items-center text-blue-800 '>
                Step {i + 1}
              </p>
              <p className='text-sm text-gray-700'>{data}</p>
            </div>
          ))}
        </div>
        {/* Main content */}
        <div className='flex-1'>
          <FormProvider {...methods}>
            <form onSubmit={methods.handleSubmit(onSubmit)}>
              {renderStep()}
            </form>
          </FormProvider>
        </div>
      </div>
    </AdminPagesWrapper>
  );
};

export default CreateTender;
