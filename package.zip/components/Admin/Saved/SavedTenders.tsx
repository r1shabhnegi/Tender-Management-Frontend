"use client";
import TenderCard from "@/components/Tender/TenderCard";
import { useGetTendersQuery } from "@/Redux/tender/tenderApi";
import { LoaderCircle } from "lucide-react";
import React from "react";

const SavedTenders = () => {
  const { data, isLoading, isError } = useGetTendersQuery("saved");

  if (isLoading)
    return (
      <div className='w-full mt-40 flex items-center justify-center text-center'>
        <LoaderCircle className='animate-spin mx-auto' />
      </div>
    );

  if (isError || data.tenders.length === 0) {
    return (
      <div className='w-full mt-40 flex items-center justify-center text-center'>
        <h1 className='text-red-500 text-xl'>Data not available</h1>
      </div>
    );
  }
  console.log(data);
  return (
    <div className='p-5 flex items-center justify-center flex-col'>
      {data?.tenders.map((tender) => (
        <TenderCard key={tender.id} />
      ))}
    </div>
  );
};

export default SavedTenders;
