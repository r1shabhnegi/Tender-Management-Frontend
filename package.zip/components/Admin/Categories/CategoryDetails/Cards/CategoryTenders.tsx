import React from "react";

interface Props {
  categoryId: string;
}
const CategoryTenders = () => {
  return <div>CategoryTenders</div>;
};

export default CategoryTenders;
