import React from "react";

const VenderBoard = () => {
  return <div>VenderBoard</div>;
};

export default VenderBoard;
