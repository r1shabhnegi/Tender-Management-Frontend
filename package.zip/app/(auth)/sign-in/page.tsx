import SigninForm from "@/components/Auth/Signin/SigninForm";

const SignIn = () => {
  return <SigninForm />;
};

export default SignIn;
