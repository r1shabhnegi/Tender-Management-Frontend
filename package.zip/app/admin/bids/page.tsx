import React from "react";

const Bids = () => {
  return <div>Bids</div>;
};

export default Bids;
