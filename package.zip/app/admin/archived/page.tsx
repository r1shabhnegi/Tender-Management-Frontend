import React from "react";

const Archived = () => {
  return <div>Archived</div>;
};

export default Archived;
