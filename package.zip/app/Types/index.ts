export interface ISignupInputs {
  name: string;
  email: string;
  password: string;
}
export interface ISigninInputs {
  email: string;
  password: string;
}

export interface IUser {
  created_at: string;
  description: string | null;
  email: string;
  full_name: string;
  id: string;

  const methods = useForm<IVenderRegistrationForm>({
    mode: "onChange",
    defaultValues: {
      fullname: "",
      email: "",
      contactNumber: "",
      password: "",

export interface IItemInfo {
  company: string;
  department: string;
  tenderNumber: string;
  tenderType: string;
  tenderScope: string;
  category: string;
  title: string;
  description: string;
  technicalPreBidQualification: string;
  technicalWeightage: string;
  commercialWeightage: string;
}

export interface ITenderSupportDocument {
  documentName: string;
  documentPurpose: string;
  document: string | ArrayBuffer | null | Blob;
}

export interface IVenderDocRequirement {
  name: string;
  type: string;
  purpose: string;
}

export interface IKeyDate {
  prePublishDate: Date | string;
  publishDate: Date | string;
  tenderSaleCloseDate: Date | string;
  clarificationStartDate: Date | string;
  clarificationEndDate: Date | string;
  revisionPublishmentDate: Date | string;
  bidSubmissionEndDate: Date | string;
  bidOpenDate: Date | string;
}
export interface ITenderFeeDetails {
  documentFee: string;
  feePayableAt: string;
  EMD: string;
  edmPayableAt: string;
  tenderLocation: string;
  tenderValue: string;
}

export interface ITenderPreQualification {
  title: string;
  description: string;
  score: string;
}

export interface IVenderRegistrationForm {
  email: string;
  password: string;
  fullname: string;
  contactNumber: string;
  confirmPassword: string;
  panCardNumber: string;
  businessName: string;
  businessClassification: string;
  establishedYear: string;
  registrationNumber: string;
  addressLineOne: string;
  addressLineTwo: string;
  locality: string;
  city: string;
  pinCode: string;
  country: string;
   panCardDoc: File | null;
  registrationDoc: File | null;
}

// export interface IBusinessRegistrationForm {
//   businessName: string;
//   businessClassification: string;
//   establishedYear: string;
//   registrationNumber: string;
//   addressLineOne: string;
//   addressLineTwo: string;
//   locality: string;
//   city: string;
//   pinCode: string;
//   country: string;
// }

// export interface IDocumentRegistrationForm {
//   registrationDoc: File;
//   panCardDoc: File;
// }

export interface IVendersTable {
  businessClassification: string;
  status: string;
  fullname: string;
  email: string;
  businessName: string;
  city: string;
  id: string;
}

export interface ICategories {
  categories: {
    id: string;
    name: string;
    type: string;
    is_sub_category: false;
    sub_category_main: string;
    scope: string;
    status: string;
    created_at: string;
  }[];
}

export interface CategoryFormData {
  name: string;
  type: string;
  scope: string;
  status: string;
  isSubCategory: boolean;
  subCategoryMain: string | null;
}

export interface CategoryFormErrors {
  categoryName: string;
  selectCategory: string;
  scope: string;
  status: string;
}

export interface Category {
  id: string;
  name: string;
  type: string;
  is_sub_category: boolean;
  sub_category_main: string;
  scope: string;
  status: string;
  created_at: string;
}

export interface IUserInfo {
  id: string;
  createdAt: string;
  description: string | null;
  email: string;
  fullname: string;
  panCardDoc: string;
  panCardNumber: string;
  phoneNumber: string;
  role: string;
  status: string;
  username: string;
}

export interface IBusinessInfo {
  id: string;
  addressLineOne: string;
  addressLineTwo: string;
  businessClassification: string;
  businessName: string;
  city: string;
  country: string;
  establishedYear: string;
  locality: string;
  pinCode: string;
  registrationNumber: string;
  registrationDoc: string;
}

export interface IVenderCategory {
  id: string;
  status: string;
  category: string;
  category_id: string;
  user_id: string;
  expires_at: string;
  created_at: Date;
}
