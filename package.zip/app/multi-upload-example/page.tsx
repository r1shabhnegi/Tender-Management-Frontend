import MultiFileUploadForm from "@/components/MultiFileUploadForm";

export default function MultiUploadExamplePage() {
  return (
    <div className='container mx-auto py-8'>
      <h1 className='text-2xl font-bold mb-6'>
        Multiple Document Upload Example
      </h1>
      <p className='mb-6 text-gray-600'>
        This example demonstrates how to upload form data along with multiple
        PDF files to AWS S3.
      </p>
      <MultiFileUploadForm />
    </div>
  );
}
